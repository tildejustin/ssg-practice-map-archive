setblock 10 -48 20 minecraft:redstone_block
setblock 10 -48 20 minecraft:air
execute as @a run tp @s 27.5 -40 30.5 0 0 
execute as @a run clear @a
kill @e[type=!player]
data merge entity @s {recipeBook:{isGuiOpen:0b,isFilteringCraftable:0b}}
effect give @a minecraft:night_vision infinite 255 true
effect give @a minecraft:saturation 1 255 true
effect give @a minecraft:instant_health 10 10 true
scoreboard players set current split 0
scoreboard players set timer ms 0
item replace entity @s inventory.4 with minecraft:heart_of_the_sea[minecraft:custom_name='{"text":"Drop to reset","color":"red","italic":false}']
item replace entity @s inventory.8 with minecraft:oak_boat[minecraft:custom_name='{"text":"Back to lobby","color":"red","italic":false}']
execute as @a run gamemode survival
gamerule fallDamage false
schedule function practice:overworld/remove-fall-damage 60t replace
