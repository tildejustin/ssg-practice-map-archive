scoreboard players set inventory selected_loadout 5
execute as @a run gamemode creative @a
function inventory:load
data merge block 12 -47 6 {front_text:{messages:["{\"text\":\"Save Inventory\",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:sh/save_inv\"}}","\"\"","\"\"","\"\""]}}