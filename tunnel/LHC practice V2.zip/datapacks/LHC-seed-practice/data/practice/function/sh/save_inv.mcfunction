scoreboard players set inventory selected_loadout 5
function inventory:store
execute as @a run clear @s
execute as @a run gamemode adventure
data merge block 12 -47 6 {front_text:{messages:["{\"text\":\"Edit Inventory\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:sh/edit_inv\"}}","\"\"","\"\"","\"\""]}}