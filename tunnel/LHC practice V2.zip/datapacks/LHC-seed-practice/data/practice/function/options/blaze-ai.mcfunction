scoreboard players add options blaze_ai 1 
scoreboard players operation options blaze_ai %= 2 c
execute if score options blaze_ai matches 1 run data modify block 12 -46 11 front_text.messages[3] set value "{\"text\":\"[Enabled]\",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:options/blaze-ai\"}}"
execute if score options blaze_ai matches 0 run data modify block 12 -46 11 front_text.messages[3] set value "{\"text\":\"[Disabled]\",\"color\":\"red\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:options/blaze-ai\"}}"