scoreboard players set inventory selected_loadout 0
execute as @a run gamemode creative @a
function inventory:load
data merge block 6 -47 12 {front_text:{messages:["{\"text\":\"Save Inventory\",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:nether/save_inv\"}}","\"\"","\"\"","\"\""]}}