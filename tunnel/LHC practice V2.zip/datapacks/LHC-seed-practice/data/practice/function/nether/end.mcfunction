title @a title ["",{"text":"Time: ","color":"white"},{"score":{"name":"timer","objective":"ms"},"color":"white"}]
function practice:nether/reset