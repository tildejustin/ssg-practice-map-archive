forceload add 10 260
forceload add 10 90
forceload add 10 20
execute as @a run tp @s 67.5 -20 26.5 -135 30
kill @e[type=!player]
data merge entity @s {recipeBook:{isGuiOpen:0b,isFilteringCraftable:0b}}
setblock 10 -24 20 redstone_block
setblock 10 -24 20 air
execute as @a run clear @a
effect give @a minecraft:night_vision infinite 255 true
effect give @a minecraft:saturation 1 255 true
effect give @a minecraft:instant_health 10 10 true
scoreboard players set current split 5
scoreboard players set timer ms 0
scoreboard players set inventory selected_loadout 3
function inventory:load
gamemode survival
fill 68 -22 24 70 -22 22 air
fill 68 -23 24 70 -23 22 red_concrete
forceload remove all