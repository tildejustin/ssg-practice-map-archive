scoreboard players set inventory selected_loadout 3
execute as @a run gamemode creative @a
function inventory:load
data merge block 10 -47 4 {front_text:{messages:["{\"text\":\"Save Inventory\",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:nether-portal/save_inv\"}}","\"\"","\"\"","\"\""]}}