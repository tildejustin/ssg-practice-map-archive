scoreboard players set inventory selected_loadout 2
function inventory:store
execute as @a run clear @s
execute as @a run gamemode adventure
data merge block 6 -47 4 {front_text:{messages:["{\"text\":\"Edit Inventory\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:overworld-portal/edit_inv\"}}","\"\"","\"\"","\"\""]}}