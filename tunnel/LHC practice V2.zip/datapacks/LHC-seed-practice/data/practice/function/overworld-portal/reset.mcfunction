data merge entity @s {recipeBook:{isGuiOpen:0b,isFilteringCraftable:0b}}
execute as @a run tp @s 25.5 -43 42.5 -145.0 0
setblock 10 -48 20 minecraft:redstone_block
setblock 10 -48 20 minecraft:air
execute as @a run clear @a
kill @e[type=!player]
effect give @a minecraft:night_vision infinite 255 true
effect give @a minecraft:saturation 1 255 true
effect give @a minecraft:instant_health 10 10 true
scoreboard players set current split 4
scoreboard players set timer ms 0
scoreboard players set inventory selected_loadout 2
function inventory:load
item replace entity @s inventory.4 with minecraft:heart_of_the_sea[minecraft:custom_name='{"text":"Drop to reset","color":"red","italic":false}']
item replace entity @s inventory.8 with minecraft:oak_boat[minecraft:custom_name='{"text":"Back to lobby","color":"red","italic":false}']
execute as @a run gamemode survival
