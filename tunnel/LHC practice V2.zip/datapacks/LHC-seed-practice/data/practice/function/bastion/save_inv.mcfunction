scoreboard players set inventory selected_loadout 0
function inventory:store
execute as @a run clear @s
execute as @a run gamemode adventure
data merge block 4 -47 10 {front_text:{messages:["{\"text\":\"Edit Inventory\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:bastion/edit_inv\"}}","\"\"","\"\"","\"\""]}}