scoreboard players set inventory selected_loadout 0
execute as @a run gamemode creative @a
function inventory:load
data merge block 4 -47 10 {front_text:{messages:["{\"text\":\"Save Inventory\",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:bastion/save_inv\"}}","\"\"","\"\"","\"\""]}}