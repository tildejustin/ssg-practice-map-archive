setblock 3 -48 3 minecraft:redstone_block
setblock 3 -48 3 minecraft:air