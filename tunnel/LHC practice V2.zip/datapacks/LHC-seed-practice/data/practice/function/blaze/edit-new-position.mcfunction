kill @e[type=!player]
kill @e[type=item]
setblock 10 -24 20 redstone_block
setblock 10 -24 20 air
execute as @a run clear @a
scoreboard players set current split 6969
effect give @a minecraft:night_vision infinite 255 true
effect give @a minecraft:saturation 1 255 true
effect give @a minecraft:instant_health 10 10 true
execute as @a run tp @s 23.5 -12 260.5 135 15
item replace entity @s hotbar.0 with minecraft:compass[minecraft:custom_name='{"text":"Drop to save new position","color":"red","italic":false}']
execute as @a run gamemode adventure