execute if score options blaze_ai matches 0 run summon minecraft:blaze 24.5 -12 260.5 {NoAI:1b}
execute if score options blaze_ai matches 1 run summon minecraft:blaze 24.5 -12 260.5
execute store result entity @e[type=blaze,limit=1] Pos[0] double 0.1 run scoreboard players get blaze x
execute store result entity @e[type=blaze,limit=1] Pos[2] double 0.1 run scoreboard players get blaze z
execute if score options blaze_random matches 1 run function practice:blaze/randomize-position