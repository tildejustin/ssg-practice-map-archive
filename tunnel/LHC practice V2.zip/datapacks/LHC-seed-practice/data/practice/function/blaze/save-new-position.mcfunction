execute store result score blaze x run data get entity @s Pos[0]
execute store result score blaze z run data get entity @s Pos[2]
scoreboard players operation blaze x *= 10 c
scoreboard players operation blaze z *= 10 c
scoreboard players add blaze x 5
scoreboard players add blaze z 5
function practice:hub