execute if score barter count matches 0 run data merge entity @e[type=item,nbt={Item:{id:"minecraft:barrier"}},limit=1] {Item:{count:4,id:"minecraft:ender_pearl"}}
execute if score barter count matches 1 run data merge entity @e[type=item,nbt={Item:{id:"minecraft:barrier"}},limit=1] {Item:{count:4,id:"minecraft:ender_pearl"}}
execute if score barter count matches 2 run data merge entity @e[type=item,nbt={Item:{id:"minecraft:barrier"}},limit=1] {Item:{count:7,id:"minecraft:soul_sand"}}
execute if score barter count matches 3 run data merge entity @e[type=item,nbt={Item:{id:"minecraft:barrier"}},limit=1] {Item:{count:3,id:"minecraft:ender_pearl"}}
execute if score barter count matches 4.. run kill @e[type=item,nbt={Item:{id:"minecraft:barrier"}}]
scoreboard players add barter count 1