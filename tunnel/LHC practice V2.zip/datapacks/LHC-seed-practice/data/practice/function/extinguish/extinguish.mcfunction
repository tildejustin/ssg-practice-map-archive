execute as @a run gamemode creative @a
schedule function practice:extinguish/set-survival 2t replace