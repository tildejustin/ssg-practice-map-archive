scoreboard objectives add split dummy
scoreboard objectives add ms dummy
scoreboard objectives add count dummy
scoreboard objectives add x dummy
scoreboard objectives add z dummy
scoreboard objectives add blaze_random dummy
scoreboard objectives add blaze_ai dummy
scoreboard objectives add deaths deathCount
scoreboard objectives add c dummy
# scoreboard players set current split 0
scoreboard players set timer ms 0
scoreboard players set barter count 0
scoreboard players set 2 c 2
scoreboard players set 5 c 5
scoreboard players set 10 c 10
scoreboard objectives setdisplay sidebar ms
scoreboard players set blaze x 245
scoreboard players set blaze z 2605
say done  