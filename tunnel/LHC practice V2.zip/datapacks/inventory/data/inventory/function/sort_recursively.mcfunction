execute store result score inventory slot_num run data get storage inventory:loadouts selected.all[-1].Slot

execute if score inventory slot_num matches -106 run function inventory:sort_offhand
execute if score inventory slot_num matches 100..103 run function inventory:sort_armor
execute if score inventory slot_num matches 9..35 run function inventory:sort_inventory
execute if score inventory slot_num matches 0..8 run data modify storage inventory:loadouts selected.hotbar append from storage inventory:loadouts selected.all[-1]

data remove storage inventory:loadouts selected.all[-1]
execute if data storage inventory:loadouts selected.all[-1] run function inventory:sort_recursively
