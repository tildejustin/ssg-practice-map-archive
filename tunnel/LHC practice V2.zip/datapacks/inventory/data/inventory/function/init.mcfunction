scoreboard objectives add slot_count dummy
scoreboard objectives add slot_num dummy
scoreboard objectives add selected_loadout dummy

scoreboard players set inventory selected_loadout 0