data modify storage inventory:loadouts selected.offhand append from storage inventory:loadouts selected.all[-1]
data modify storage inventory:loadouts selected.offhand[-1].Slot set value 0