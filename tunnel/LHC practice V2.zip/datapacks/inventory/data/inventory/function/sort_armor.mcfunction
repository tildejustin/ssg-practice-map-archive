data modify storage inventory:loadouts selected.armor append from storage inventory:loadouts selected.all[-1]

execute store result storage inventory:loadouts selected.armor[-1].Slot byte 1 run scoreboard players remove inventory slot_num 100
scoreboard players add inventory slot_num 100