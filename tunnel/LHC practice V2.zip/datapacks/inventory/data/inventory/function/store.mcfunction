data modify storage inventory:loadouts selected.all set from entity @s Inventory
execute store result score inventory slot_count run data get storage inventory:loadouts selected.all
execute if score inventory slot_count matches 1.. run function inventory:sort_recursively

execute if score inventory selected_loadout matches 0 run data modify storage inventory:loadouts loadout_0 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 1 run data modify storage inventory:loadouts loadout_1 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 2 run data modify storage inventory:loadouts loadout_2 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 3 run data modify storage inventory:loadouts loadout_3 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 4 run data modify storage inventory:loadouts loadout_4 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 5 run data modify storage inventory:loadouts loadout_5 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 6 run data modify storage inventory:loadouts loadout_6 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 7 run data modify storage inventory:loadouts loadout_7 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 8 run data modify storage inventory:loadouts loadout_8 set from storage inventory:loadouts selected
execute if score inventory selected_loadout matches 9 run data modify storage inventory:loadouts loadout_9 set from storage inventory:loadouts selected
data remove storage inventory:loadouts selected