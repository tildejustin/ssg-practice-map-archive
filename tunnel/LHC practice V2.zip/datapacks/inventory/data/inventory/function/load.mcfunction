clear @s
setblock 0 0 0 white_shulker_box

execute if score inventory selected_loadout matches 0 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_0
execute if score inventory selected_loadout matches 1 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_1
execute if score inventory selected_loadout matches 2 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_2
execute if score inventory selected_loadout matches 3 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_3
execute if score inventory selected_loadout matches 4 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_4
execute if score inventory selected_loadout matches 5 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_5
execute if score inventory selected_loadout matches 6 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_6
execute if score inventory selected_loadout matches 7 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_7
execute if score inventory selected_loadout matches 8 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_8
execute if score inventory selected_loadout matches 9 run data modify storage inventory:loadouts selected set from storage inventory:loadouts loadout_9

data modify block 0 0 0 Items set from storage inventory:loadouts selected.hotbar
item replace entity @s hotbar.0 from block 0 0 0 container.0
item replace entity @s hotbar.1 from block 0 0 0 container.1
item replace entity @s hotbar.2 from block 0 0 0 container.2
item replace entity @s hotbar.3 from block 0 0 0 container.3
item replace entity @s hotbar.4 from block 0 0 0 container.4
item replace entity @s hotbar.5 from block 0 0 0 container.5
item replace entity @s hotbar.6 from block 0 0 0 container.6
item replace entity @s hotbar.7 from block 0 0 0 container.7
item replace entity @s hotbar.8 from block 0 0 0 container.8
data modify block 0 0 0 Items set value []

data modify block 0 0 0 Items set from storage inventory:loadouts selected.inventory
item replace entity @s inventory.0 from block 0 0 0 container.0
item replace entity @s inventory.1 from block 0 0 0 container.1
item replace entity @s inventory.2 from block 0 0 0 container.2
item replace entity @s inventory.3 from block 0 0 0 container.3
item replace entity @s inventory.4 from block 0 0 0 container.4
item replace entity @s inventory.5 from block 0 0 0 container.5
item replace entity @s inventory.6 from block 0 0 0 container.6
item replace entity @s inventory.7 from block 0 0 0 container.7
item replace entity @s inventory.8 from block 0 0 0 container.8
item replace entity @s inventory.9 from block 0 0 0 container.9
item replace entity @s inventory.10 from block 0 0 0 container.10
item replace entity @s inventory.11 from block 0 0 0 container.11
item replace entity @s inventory.12 from block 0 0 0 container.12
item replace entity @s inventory.13 from block 0 0 0 container.13
item replace entity @s inventory.14 from block 0 0 0 container.14
item replace entity @s inventory.15 from block 0 0 0 container.15
item replace entity @s inventory.16 from block 0 0 0 container.16
item replace entity @s inventory.17 from block 0 0 0 container.17
item replace entity @s inventory.18 from block 0 0 0 container.18
item replace entity @s inventory.19 from block 0 0 0 container.19
item replace entity @s inventory.20 from block 0 0 0 container.20
item replace entity @s inventory.21 from block 0 0 0 container.21
item replace entity @s inventory.22 from block 0 0 0 container.22
item replace entity @s inventory.23 from block 0 0 0 container.23
item replace entity @s inventory.24 from block 0 0 0 container.24
item replace entity @s inventory.25 from block 0 0 0 container.25
item replace entity @s inventory.26 from block 0 0 0 container.26
data modify block 0 0 0 Items set value []

data modify block 0 0 0 Items set from storage inventory:loadouts selected.offhand
item replace entity @s weapon.offhand from block 0 0 0 container.0
data modify block 0 0 0 Items set value []

data modify block 0 0 0 Items set from storage inventory:loadouts selected.armor
item replace entity @s armor.feet from block 0 0 0 container.0
item replace entity @s armor.legs from block 0 0 0 container.1
item replace entity @s armor.chest from block 0 0 0 container.2
item replace entity @s armor.head from block 0 0 0 container.3

setblock 0 0 0 air

data remove storage inventory:loadouts selected