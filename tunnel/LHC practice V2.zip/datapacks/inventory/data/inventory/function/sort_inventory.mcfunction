data modify storage inventory:loadouts selected.inventory append from storage inventory:loadouts selected.all[-1]

execute store result storage inventory:loadouts selected.inventory[-1].Slot byte 1 run scoreboard players remove inventory slot_num 9
scoreboard players add inventory slot_num 9