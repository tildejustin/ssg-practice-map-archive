execute as @a run gamemode survival @a
execute as @a if score current split matches 67676767 run gamemode adventure @a