execute as @a unless entity @s[nbt={Fire:-20s}] run function practice:extinguish/extinguish
kill @e[type=!player]
execute as @a run clear @a
effect give @a minecraft:saturation 1 255 true
effect give @a minecraft:instant_health 10 10 true
execute as @a run tp @s 8.5 -47 8.5 0 0
execute as @a run gamemode adventure @a
scoreboard players set current split 67676767