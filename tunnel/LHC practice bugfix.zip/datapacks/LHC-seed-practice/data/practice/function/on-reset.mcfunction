execute as @a run effect clear @a
forceload add 13 18 71 294

execute if score current split matches 0 run function practice:overworld/reset
execute if score current split matches 1 run function practice:nether/reset
execute if score current split matches 2 run function practice:bastion/reset
execute if score current split matches 3 run function practice:pearls/reset
execute if score current split matches 4 run function practice:overworld-portal/reset
execute if score current split matches 5 run function practice:nether-portal/reset
execute if score current split matches 6 run function practice:sh/reset

execute as @a unless entity @s[nbt={Fire:-20s}] run function practice:extinguish/extinguish

scoreboard players set @a deaths 0

forceload remove all