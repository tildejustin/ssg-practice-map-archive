data merge entity @s {recipeBook:{isGuiOpen:0b,isFilteringCraftable:0b}}
execute as @a run tp @s 16.5 3 22.5 0 0
setblock 10 0 20 minecraft:redstone_block
setblock 10 0 20 minecraft:air
execute if score options extended_sh matches 1 run setblock 14 5 28 minecraft:end_portal_frame[facing=south]
execute if score options extended_sh matches 1 run schedule clear practice:practice/on-end
execute as @a run clear @a
kill @e[type=!player]
effect give @a minecraft:night_vision infinite 255 true
effect give @a minecraft:saturation 1 255 true
effect give @a minecraft:instant_health 10 10 true
scoreboard players set current split 6
scoreboard players set timer ms 0
scoreboard players set inventory selected_loadout 5
function inventory:load
execute as @a run gamemode survival