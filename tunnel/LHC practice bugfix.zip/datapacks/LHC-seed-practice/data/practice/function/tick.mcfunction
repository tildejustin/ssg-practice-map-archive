# extraeneous
execute as @a if entity @s[scores={deaths=1}] run function practice:on-reset
execute as @a at @s if block ~ ~ ~ minecraft:nether_portal run function practice:on-end
execute as @a in minecraft:overworld if entity @s[nbt={Dimension:"minecraft:the_nether"}] run function practice:on-end
execute if score options extended_sh matches 1 if score current split matches 6 in minecraft:overworld as @a[nbt={Dimension:"minecraft:the_end"}] run function practice:on-end
# Reset
execute as @a at @s if entity @e[type=item,nbt={Item:{id:"minecraft:heart_of_the_sea"}},distance=..2] run function practice:on-reset
execute as @a at @s if entity @e[type=item,nbt={Item:{id:"minecraft:golden_axe"}},distance=..2] run function practice:on-reset
execute as @a at @s if score current split matches 1..3 if block ~ ~-1 ~ red_concrete run function practice:on-reset
execute as @a at @s if score current split matches 5 if block ~ ~-1 ~ red_concrete run function practice:on-reset

# hub
execute as @a at @s if entity @e[type=item,nbt={Item:{id:"minecraft:oak_boat"}},distance=..2] run function practice:hub

# change blaze
execute as @a if score current split matches 6969 if entity @e[type=item,nbt={Item:{id:"minecraft:compass"}}] run function practice:blaze/save-new-position

# Check end conditions
execute if score current split matches 0 as @a on vehicle if entity @e[type=boat] as @a if data entity @s {SelectedItem:{id:"minecraft:fire_charge"}} if block 28 -39 38 minecraft:obsidian run function practice:on-end
execute if score current split matches 1 as @a on vehicle if entity @e[type=boat] as @a if data entity @s {SelectedItem:{id:"minecraft:fire_charge"}} positioned 70 -21 23 if predicate practice:portal-completed run function practice:on-end
execute if score current split matches 2 as @a if entity @e[type=ender_pearl,limit=1] run function practice:on-end
execute if score current split matches 3 as @a on vehicle if entity @e[type=boat] as @a if data entity @s {SelectedItem:{id:"minecraft:fire_charge"}} positioned 70 -21 23 if predicate practice:portal-completed run function practice:on-end
execute if score current split matches 4 as @a on vehicle if entity @e[type=boat] as @a if data entity @s {SelectedItem:{id:"minecraft:fire_charge"}} if block 28 -39 38 minecraft:obsidian run function practice:on-end
execute if score current split matches 5 as @a on vehicle if entity @e[type=boat] as @a if data entity @s {SelectedItem:{id:"minecraft:fire_charge"}} positioned 70 -21 23 if predicate practice:portal-completed run function practice:on-end
execute if score options extended_sh matches 0 if score current split matches 6 as @a if block 17 5 29 minecraft:end_portal_frame[eye=true] if block 17 5 31 minecraft:end_portal_frame[eye=true] if block 14 5 32 minecraft:end_portal_frame[eye=true] if block 13 5 30 minecraft:end_portal_frame[eye=true] if block 13 5 29 minecraft:end_portal_frame[eye=true] if block 13 5 29 minecraft:end_portal_frame[eye=true] if block 15 5 28 minecraft:end_portal_frame[eye=true] if block 14 5 28 minecraft:end_portal_frame[eye=true] if block 16 5 28 minecraft:end_portal_frame[eye=true] if predicate practice:in-end-portal run function practice:on-end

# Start timers
execute as @a if score current split matches 0 unless predicate practice:overworld-start run scoreboard players add timer ms 5
execute as @a if score current split matches 1..2 unless predicate practice:nether-bastion run scoreboard players add timer ms 5
execute as @a if score current split matches 3 unless predicate practice:pearls run scoreboard players add timer ms 5
execute as @a if score current split matches 4 unless predicate practice:ow-portal run scoreboard players add timer ms 5
execute as @a if score current split matches 5 unless predicate practice:nether-portal run scoreboard players add timer ms 5
execute as @a if score current split matches 6 unless predicate practice:sh run scoreboard players add timer ms 5

# Check barters
execute as @a if entity @e[type=item,nbt={Item:{id:"minecraft:barrier"}},limit=1] run function practice:barter/modify-item-nbt