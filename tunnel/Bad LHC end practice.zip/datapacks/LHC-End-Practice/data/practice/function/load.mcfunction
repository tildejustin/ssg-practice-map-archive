scoreboard objectives add ms dummy
scoreboard objectives add rotation dummy
scoreboard objectives add deaths deathCount
scoreboard objectives add flag dummy
scoreboard players set inventory selected_loadout 0
scoreboard players set timer ms 0
scoreboard players set isPlaying flag 0
scoreboard objectives setdisplay sidebar ms
say hello