gamemode creative @a
kill @e[type=#practice:remove]
scoreboard players set @s deaths 0
fill 102 48 80 -80 48 -80 air replace #practice:remove
fill 102 49 80 -80 49 -80 air replace #practice:remove
fill 102 50 80 -80 50 -80 air replace #practice:remove
fill 102 57 80 -80 57 -80 air replace #practice:remove
fill 80 58 80 -80 58 -80 air replace #practice:remove
fill 80 59 80 -80 59 -80 air replace #practice:remove
fill 80 60 80 -80 60 -80 air replace #practice:remove
fill 80 61 80 -80 61 -80 air replace #practice:remove
fill 80 62 80 -80 62 -80 air replace #practice:remove
fill 80 63 80 -80 63 -80 air replace #practice:remove
fill 80 75 80 -80 75 -80 air replace #practice:remove
fill 80 76 80 -80 76 -80 air replace #practice:remove
fill 80 77 80 -80 77 -80 air replace #practice:remove
fill 80 78 80 -80 78 -80 air replace #practice:remove
fill 80 79 80 -80 79 -80 air replace #practice:remove
fill 80 80 80 -80 80 -80 air replace #practice:remove
fill 80 81 80 -80 81 -80 air replace #practice:remove
fill 80 82 80 -80 82 -80 air replace #practice:remove
fill 80 83 80 -80 83 -80 air replace #practice:remove
fill 80 84 80 -80 84 -80 air replace #practice:remove
fill 80 85 80 -80 85 -80 air replace #practice:remove
fill 80 86 80 -80 86 -80 air replace #practice:remove
fill 80 87 80 -80 87 -80 air replace #practice:remove
fill 80 88 80 -80 88 -80 air replace #practice:remove
fill 80 89 80 -80 89 -80 air replace #practice:remove
fill 80 90 80 -80 90 -80 air replace #practice:remove
fill 80 91 80 -80 91 -80 air replace #practice:remove
fill 80 92 80 -80 92 -80 air replace #practice:remove
fill 80 93 80 -80 93 -80 air replace #practice:remove
fill 80 94 80 -80 94 -80 air replace #practice:remove
fill 80 95 80 -80 95 -80 air replace #practice:remove
fill 80 96 80 -80 96 -80 air replace #practice:remove
fill 80 97 80 -80 97 -80 air replace #practice:remove
fill 80 98 80 -80 98 -80 air replace #practice:remove
fill 80 99 80 -80 99 -80 air replace #practice:remove
fill 80 100 80 -80 100 -80 air replace #practice:remove
fill 80 101 80 -80 101 -80 air replace #practice:remove
fill 80 102 80 -80 102 -80 air replace #practice:remove
fill 80 103 80 -80 103 -80 air replace #practice:remove
fill 80 104 80 -80 104 -80 air replace #practice:remove
fill 80 105 80 -80 105 -80 air replace #practice:remove

effect give @s minecraft:saturation 1 255 true
effect give @s minecraft:instant_health 10 10 true
effect give @s minecraft:night_vision infinite 255 true

tp @s 120 101 0 90 0
gamemode adventure @a
execute if entity @s[nbt={Fire:-20s}] run function practice:extinguish
clear @a
scoreboard players set isPlaying flag 0
scoreboard players set timer ms 0
execute as @a at @s run summon area_effect_cloud ~ ~ ~ {Duration:10000000}