execute store result score dragon rotation run random value 0..35999

execute if score dragon rotation matches 0..4499 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[22.5f,0f]}
execute if score dragon rotation matches 4500..8999 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[67.5f,0f]}
execute if score dragon rotation matches 9000..13499 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[112.5f,0f]}
execute if score dragon rotation matches 13500..17999 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[157.5f,0f]}
execute if score dragon rotation matches 18000..22499 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[202.5f,0f]}
execute if score dragon rotation matches 22500..26999 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[247.5f,0f]}
execute if score dragon rotation matches 27000..31499 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[292.5f,0f]}
execute if score dragon rotation matches 31500..35999 in minecraft:the_end run summon minecraft:ender_dragon 0.0 128 0.0 {DragonPhase:0b,Rotation:[337.5f,0f]}

execute store result entity @e[type=minecraft:ender_dragon,limit=1] Rotation[0] float 0.01 run scoreboard players get dragon rotation