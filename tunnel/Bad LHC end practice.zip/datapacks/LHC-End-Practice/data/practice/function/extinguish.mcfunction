gamemode creative @a
schedule function practice:set-adventure 2t replace