function inventory:store
clear @a
gamemode adventure @a
data merge block 120 102 2 {front_text:{messages:["{\"text\":\"Edit Inventory\",\"color\":\"white\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:edit-inv\"}}","\"\"","\"\"","\"\""]}}