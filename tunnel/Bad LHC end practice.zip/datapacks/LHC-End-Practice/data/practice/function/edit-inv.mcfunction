gamemode creative @a
function inventory:load
data merge block 120 102 2 {front_text:{messages:["{\"text\":\"Save Inventory\",\"color\":\"green\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function practice:save-inv\"}}","\"\"","\"\"","\"\""]}}
