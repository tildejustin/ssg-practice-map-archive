scoreboard players add timer ms 1000
title @a title ["",{"text":"Time: ","color":"white"},{"score":{"name":"timer","objective":"ms"},"color":"white"}]
execute in minecraft:the_end as @a run function practice:hub