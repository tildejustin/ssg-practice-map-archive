function practice:spawn-dragon
tp @s 100.5 49 0.5 90 0
gamemode survival @a
function inventory:load
scoreboard players set isPlaying flag 1
item replace entity @s inventory.4 with minecraft:heart_of_the_sea