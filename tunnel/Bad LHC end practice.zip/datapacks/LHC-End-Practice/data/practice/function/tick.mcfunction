execute as @a in minecraft:the_end if entity @e[type=item,nbt={Item:{id:"minecraft:heart_of_the_sea"}}] run function practice:hub
# execute in minecraft:the_end if entity @e[type=minecraft:arrow] run schedule function practice:remove-arrow 1t append
execute as @a in minecraft:the_end if score @s deaths matches 1.. run function practice:hub
execute as @a in minecraft:the_end if predicate practice:bout-to-die run function practice:hub
execute in minecraft:the_end if entity @e[type=ender_dragon] store result bossbar minecraft:dragon value run data get entity @e[type=ender_dragon,limit=1] Health
execute if score isPlaying flag matches 1 run scoreboard players add timer ms 5
execute if score isPlaying flag matches 1 unless entity @e[type=ender_dragon,limit=1] run function practice:on-end