execute in overworld run tp @a -97.5 9 136.5 0.6 14.5
gamemode survival @p
clear @p
effect give @p minecraft:instant_health 1 100
replaceitem entity @p hotbar.0 white_bed
replaceitem entity @p hotbar.1 yellow_bed
replaceitem entity @p hotbar.2 white_bed
replaceitem entity @p hotbar.3 yellow_bed
replaceitem entity @p hotbar.6 minecraft:flint_and_steel
replaceitem entity @p hotbar.7 minecraft:iron_pickaxe
replaceitem entity @p hotbar.8 minecraft:obsidian 2
kill @e[type=item]