# 144 66 185 149 65 137
setblock 144 66 185 structure_block{name:"ow2",rotation:"NONE",mirror:"NONE",mode:"LOAD"}
setblock 149 65 137 structure_block{name:"ow1",rotation:"NONE",mirror:"NONE",mode:"LOAD"}
setblock 144 67 185 minecraft:redstone_block
setblock 149 66 137 minecraft:redstone_block
kill @e[ type= minecraft:item ]