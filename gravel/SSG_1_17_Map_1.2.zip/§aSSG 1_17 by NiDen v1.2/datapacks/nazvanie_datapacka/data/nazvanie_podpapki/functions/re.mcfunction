clear @p
give @p minecraft:carrot_on_a_stick{perls:1,display:{Name:"{\"text\":\"Reload\"}"}}
give @p minecraft:carrot_on_a_stick{clon:1,display:{Name:"{\"text\":\"clone\"}"}}
clone 147 20 132 191 25 239 147 70 132
clone 147 25 132 191 30 239 147 75 132
kill @e[ type= minecraft:item ]
kill @a
