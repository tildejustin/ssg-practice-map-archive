function nazvanie_podpapki:ow
execute in minecraft:overworld run tp @p 154.48 35.00 147.48 -89.69 2.25
clear @a
scoreboard players set @a djumpbb 0
setblock 157 44 178 minecraft:air