scoreboard players set @a t 0
setblock 157 44 178 minecraft:redstone_block
scoreboard players add @a t 1
gamemode survival @p
