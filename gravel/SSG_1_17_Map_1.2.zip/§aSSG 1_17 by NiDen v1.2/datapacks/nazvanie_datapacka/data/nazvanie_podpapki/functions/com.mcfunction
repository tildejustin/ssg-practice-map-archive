execute as @a[scores={djumpbb=1..}] run clone 151 20 137 164 30 153 151 70 137
execute as @a[scores={djumpbb=1..}] run execute in minecraft:overworld run tp @a 155.52 34.00 135.48 1170.01 15.60
execute as @a[scores={djumpbb=1..}] run execute in minecraft:overworld run kill @e[ type= minecraft:item ]
execute as @a[scores={djumpbb=1..}] run clear @p
execute as @a[scores={djumpbb=1..}] run setblock 145 91 145 minecraft:air
scoreboard players set @a djumpbb 0