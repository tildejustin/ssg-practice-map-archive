execute as @a[scores={djumpbb=1..}] run setblock 149 65 137 structure_block{name:"ow1",rotation:"NONE",mirror:"NONE",mode:"LOAD"}
execute as @a[scores={djumpbb=1..}] run setblock 149 66 137 minecraft:redstone_block
execute as @a[scores={djumpbb=1..}] run kill @e[ type= minecraft:item ]
execute as @a[scores={djumpbb=1..}] run item replace entity @p weapon.mainhand with minecraft:obsidian 20

execute as @a[scores={djumpbb=1..}] run scoreboard players set @a djumpbb 0