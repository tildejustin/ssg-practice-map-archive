
scoreboard players set @a djumpbb 0
execute in minecraft:overworld run tp @p 154.48 35.00 147.48 -89.69 2.25
clear @p
effect give @p minecraft:instant_health 1 100
effect give @p minecraft:saturation 1 100
gamemode survival @p
setblock 157 44 178 minecraft:air
setblock 147 91 142 minecraft:air
setblock 145 91 145 minecraft:air