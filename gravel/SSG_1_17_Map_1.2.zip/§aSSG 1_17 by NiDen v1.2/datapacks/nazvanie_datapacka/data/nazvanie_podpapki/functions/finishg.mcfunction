function nazvanie_podpapki:ow
execute in minecraft:overworld run tp @a 155.52 34.00 135.48 1170.01 15.60
clear @a
setblock 145 91 145 minecraft:air
scoreboard players set @a djumpbb 0