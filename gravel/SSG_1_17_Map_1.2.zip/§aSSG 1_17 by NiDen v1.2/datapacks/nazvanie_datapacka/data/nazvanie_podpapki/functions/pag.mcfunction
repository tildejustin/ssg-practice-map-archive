gamemode survival @p
scoreboard players set @a djumpbb 0
setblock 147 91 142 minecraft:redstone_block
setblock 149 65 137 structure_block{name:"ow1",rotation:"NONE",mirror:"NONE",mode:"LOAD"}
execute in minecraft:overworld run tp @p 159.77 74.00 145.03 -89.54 3.30
kill @e[ type= minecraft:item ]
item replace entity @p weapon.mainhand with minecraft:obsidian 20