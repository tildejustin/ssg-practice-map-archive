scoreboard players set @p time 0
gamemode survival @a
scoreboard players set @a djumpbb 0
setblock 145 91 145 minecraft:redstone_block
item replace entity @p container.0 from block 152 34 132 container.0
item replace entity @p container.1 from block 152 34 132 container.1
item replace entity @p container.2 from block 152 34 132 container.2
item replace entity @p container.3 from block 152 34 132 container.3
item replace entity @p container.4 from block 152 34 132 container.4
item replace entity @p container.5 from block 152 34 132 container.5
item replace entity @p container.6 from block 152 34 132 container.6
item replace entity @p container.7 from block 152 34 132 container.7
item replace entity @p container.8 from block 152 34 132 container.8
item replace entity @p weapon.offhand from block 152 34 132 container.9