clone 147 20 132 191 25 239 147 70 132
clone 147 25 132 191 30 239 147 75 132
kill @e[ type= minecraft:item ]