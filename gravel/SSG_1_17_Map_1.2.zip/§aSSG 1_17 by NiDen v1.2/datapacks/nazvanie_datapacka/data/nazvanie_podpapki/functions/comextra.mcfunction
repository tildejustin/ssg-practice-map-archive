clone 151 20 137 164 30 153 151 70 137
execute in minecraft:overworld run tp @a 155.52 34.00 135.48 1170.01 15.60
execute in minecraft:overworld run kill @e[ type= minecraft:item ]
clear @p
setblock 145 91 145 minecraft:air
scoreboard players set @a djumpbb 0
