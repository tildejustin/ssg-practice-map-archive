
execute as @a[scores={t=1..}] run clear @p
function nazvanie_podpapki:ow
execute in minecraft:overworld run tp @p 161 71 194 0 0

execute as @a[scores={t=1..}] run scoreboard players set @a time 0




execute as @a[scores={t=1..}] run scoreboard players set @a t 0