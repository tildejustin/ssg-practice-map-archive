execute as @a[scores={1=1..},nbt={SelectedItem:{tag:{perls:1}}}] run function nazvanie_podpapki:re
execute as @a[scores={1=1..},nbt={SelectedItem:{tag:{clon:1}}}] run function nazvanie_podpapki:clon
scoreboard players set @a 1 0